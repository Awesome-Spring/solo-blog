title: Mysql索引学习
date: '2019-09-08 21:56:27'
updated: '2019-09-08 21:56:27'
tags: [Mysql]
permalink: /articles/2019/09/08/1567950987521.html
---
### 索引简介
MySQL官方对索引的定义为：索引(Index)是帮助MySQL高校获取数据的数据结构。
可以得到索引的**本质**：索引是**数据结构**
我们可以简单理解为"**排好序的快速查找数据结构**"。

![image.png](https://img.hacpai.com/file/2019/09/image-05e7c014.png)

一般来说索引本身也很大，不可能全部存储在内存中，因此索引往往以文件形式存储在硬盘上。
我们平时所说的索引，如果没有特别指明，都是指B树(多路搜索树，并不一定是二叉树)结构组织的索引。其中聚集索引，次要索引，覆盖索引，复合索引，前缀索引，唯一索引默认都是使用B+树索引，统称索引。当然,除了B+树这种类型的索引之外，还有哈希索引(hash index)等。

### mysql索引分类
**1.单值索引**
	即一个索引只包含单个列，一个表可以有多个单列索引。
**2.唯一索引**
	索引列的值必须唯一，但允许有空值。
**3.复合索引**
	即一个索引包含多个列。
**4.全文索引**
	对文本的内容进行分词，进行搜索。

### 基本语法  
**创建**
` CREATE [UNIQUE] INDEX  indexName ON mytable(columnname(length));  `
 如果是CHAR,VARCHAR类型，length可以小于字段实际长度；  
如果是BLOB和TEXT类型，必须指定length。  
` ALTER mytable ADD [UNIQUE]  INDEX [indexName] ON(columnname(length));  `
**删除**
` DROP INDEX [indexName] ON mytable;  `
**查看**
` SHOW INDEX FROM table_name`
**使用ALTER 命令添加和删除索引**

```
ALTER TABLE tbl_name ADD PRIMARY KEY (column_list): 该语句添加一个主键，这意味着索引值必须是唯一的，且不能为NULL。
ALTER TABLE tbl_name ADD UNIQUE index_name (column_list): 这条语句创建索引的值必须是唯一的（除了NULL外，NULL可能会出现多次）。
ALTER TABLE tbl_name ADD INDEX index_name (column_list): 添加普通索引，索引值可出现多次。
ALTER TABLE tbl_name ADD FULLTEXT index_name (column_list):该语句指定了索引为 FULLTEXT ，用于全文索引。
```


### mysql索引结构
#### BTree 索引
Btree索引(或Balanced Tree)，是一种很普遍的数据库索引结构，oracle默认的索引类型（本文也主要依据oracle来讲）。其特点是定位高效、利用率高、自我平衡，特别适用于高基数字段，定位单条或小范围数据非常高效。理论上，使用Btree在亿条数据与100条数据中定位记录的花销相同。
由于Btree索引对结构的利用率很高，定位高效。当1千万条数据时，Btree索引也是三层结构。定位记录仍只需要三次I/O，这就是为什么说100条数据和1千万条数据的定位，在btree索引中的花销是一样的。
### Hash 索引
由于HASH的唯一及类似键值对的形式，很适合作为索引。
HASH索引可以一次定位，不需要像树形索引那样逐层查找,因此具有极高的效率。但是，这种高效是有条件的，即只在“=”和“in”条件下高效，对于范围查询、排序及组合索引仍然效率不高。
#### full-text 全文索引
目前只有MyISAM引擎支持。其可以在CREATE TABLE ，ALTER TABLE ，CREATE INDEX 使用，不过目前只有 CHAR、VARCHAR ，TEXT 列上可以创建全文索引。
全文索引并不是和MyISAM一起诞生的，它的出现是为了解决WHERE name LIKE “%word%"这类针对文本的模糊查询效率较低的问题。
#### R-Tree 索引
RTREE在MySQL很少使用，仅支持geometry数据类型，支持该类型的存储引擎只有MyISAM、BDb、InnoDb、NDb、Archive几种。
相对于BTREE，RTREE的优势在于范围查找。
### 哪些情况需要创建索引
1.主键自动建立唯一索引。
2.频繁作为查询的条件的字段应该创建索引。
3.查询中与其他表关联的字段，外键关系建立索引。
4.频繁更新的字段不适合创建索引，因为每次更新不单单是更新了记录还会更新索引，加重IO负担。
5.Where条件里用不到的字段不创建索引。
6.查询中排序的字段，排序字段若通过索引去访问将大大提高排序的速度。
7.查询中统计或者分组字段。

### 哪些情况不要创建索引
1.表记录太少
2.经常增删改的表
3.数据重复且分布平均的表字段，因此应该只为经常查询和经常排序的数据列建立索引。
注意，如果某个数据列包含许多重复的内容，为它建立索引就没有太大的实际效果。



