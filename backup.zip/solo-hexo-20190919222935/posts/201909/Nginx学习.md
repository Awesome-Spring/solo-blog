title: Nginx学习
date: '2019-09-18 23:01:16'
updated: '2019-09-18 23:06:31'
tags: [Nginx]
permalink: /articles/2019/09/18/1568818876668.html
---
![](https://img.hacpai.com/bing/20180902.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### Nginx是什么？
Nginx("engine x")是一款是由俄罗斯的程序设计师Igor Sysoev所开发高性能的 **Web和 反向代理 服务器**，也是一个 IMAP/POP3/SMTP **代理服务器**。
在高连接并发的情况下，Nginx是Apache服务器不错的替代品。能经受高负
载的考验,有报告表明能支持高达 50,000 个并发连接数
### Nginx能做什么
——正向代理

——反向代理

——负载均衡

——HTTP服务器（动静分离）

**正向代理**：意思是一个位于客户端和原始服务器(origin server)之间的服务器，为了从原始服务器取得内容，客户端向代理发送一个请求并指定目标(原始服务器)，然后代理向原始服务器转交请求并将获得的内容返回给客户端。客户端才能使用正向代理。
![正向代理图示](https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=2138f66fae0f4bfb98dd960662261395/5ab5c9ea15ce36d376031ac030f33a87e950b13f.jpg)

**反向代理**：是代理服务器的一种。服务器根据客户端的请求，从其关联的一组或多组后端服务器（如Web服务器）上获取资源，然后再将这些资源返回给客户端，**客户端只会得知反向代理的IP地址，而不知道在代理服务器后面的服务器簇的存在**
![反向代理](https://gss1.bdstatic.com/-vo3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike80%2C5%2C5%2C80%2C26/sign=4b1a652cc51349546a13e0363727f93d/3812b31bb051f81993dddee7d4b44aed2f73e7a7.jpg)

**负载均衡**：增加服务器的数量，然后将请求分发到各个服务器上，将原先请求集中到单个服务器上的情况改为将请求分发到多个服务器上，将负载分发到不同的服务器。
![负载均衡.png](https://img.hacpai.com/file/2019/09/负载均衡-74defd93.png)

**动静分离**：是将网站静态资源（HTML，JavaScript，CSS，img等文件）与后台应用分开部署，提高用户访问静态代码的速度，降低对后台应用访问。

![动静分离](https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1598116450,1840695309&fm=26&gp=0.jpg)

### Nginx的安装
系统平台：CentOS 7
#### 一、安装编译工具及库文件

yum -y install make zlib zlib-devel gcc-c++ libtool  openssl openssl-devel

#### 二、首先要安装 PCRE

PCRE 作用是让 Nginx 支持 Rewrite 功能。

1、下载 PCRE 安装包，下载地址： [http://downloads.sourceforge.net/project/pcre/pcre/8.35/pcre-8.35.tar.gz](http://downloads.sourceforge.net/project/pcre/pcre/8.35/pcre-8.35.tar.gz)
```shell
[root@hadop]# cd /usr/local/src/
[root@hadop]# wget  http://downloads.sourceforge.net/project/pcre/pcre/8.35/pcre-8.35.tar.gz
```
2、解压安装包:

```shell
[root@hadop src]# tar zxvf pcre-8.35.tar.gz
```

3、进入安装包目录

```shell
[root@hadop]# cd pcre-8.35
```

4、编译安装 

```shell
[root@hadop pcre-8.35]#  ./configure [root@bogon pcre-8.35]# make&& make install
```

5、查看pcre版本

```shell
[root@hadop pcre-8.35]# pcre-config --version
```

#### 安装 Nginx

1、下载 Nginx，下载地址：[http://nginx.org/download/nginx-1.6.2.tar.gz](http://nginx.org/download/nginx-1.6.2.tar.gz)

```shell
[root@hadop src]# cd /usr/local/src/  [root@bogon src]# wget http://nginx.org/download/nginx-1.6.2.tar.gz
```
安装包

```shell
[root@hadop  src]# tar zxvf nginx-1.6.2.tar.gz
```

3、进入安装包目录

```shell
[root@hadop  src]# cd nginx-1.6.2
```

4、编译安装

```shell
[root@hadop  nginx-1.6.2]#  ./configure --prefix=/usr/local/webserver/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre=/usr/local/src/pcre-8.35
[root@hadop  nginx-1.6.2]# make 
[root@hadop  nginx-1.6.2]# make install
```

5、查看nginx版本

```shell
[root@hadop  nginx-1.6.2]#  /usr/local/webserver/nginx/sbin/nginx -v
```

**到此，nginx安装完成**

#### Nginx 配置

创建 Nginx 运行使用的用户 www：

```shell
[root@hadop  conf]#  /usr/sbin/groupadd www [root@bogon conf]#  /usr/sbin/useradd -g www www
```

配置nginx.conf ，将/usr/local/webserver/nginx/conf/nginx.conf替换为以下内容
```shell
[root@hadop  conf]# cat /usr/local/webserver/nginx/conf/nginx.conf

user www www;
worker_processes 2; #设置值和CPU核心数一致
error_log /usr/local/webserver/nginx/logs/nginx_error.log crit; #日志位置和日志级别
pid /usr/local/webserver/nginx/nginx.pid;
#Specifies the value for maximum file descriptors that can be opened by this process.
worker_rlimit_nofile 65535;
events
{
  use epoll;
  worker_connections 65535;
}
http
{
  include mime.types;
  default_type application/octet-stream;
  log_format main  '$remote_addr - $remote_user [$time_local] "$request" '
               '$status $body_bytes_sent "$http_referer" '
               '"$http_user_agent" $http_x_forwarded_for';
  
#charset gb2312;
     
  server_names_hash_bucket_size 128;
  client_header_buffer_size 32k;
  large_client_header_buffers 4 32k;
  client_max_body_size 8m;
     
  sendfile on;
  tcp_nopush on;
  keepalive_timeout 60;
  tcp_nodelay on;
  fastcgi_connect_timeout 300;
  fastcgi_send_timeout 300;
  fastcgi_read_timeout 300;
  fastcgi_buffer_size 64k;
  fastcgi_buffers 4 64k;
  fastcgi_busy_buffers_size 128k;
  fastcgi_temp_file_write_size 128k;
  gzip on; 
  gzip_min_length 1k;
  gzip_buffers 4 16k;
  gzip_http_version 1.0;
  gzip_comp_level 2;
  gzip_types text/plain application/x-javascript text/css application/xml;
  gzip_vary on;
 
 #limit_zone crawler $binary_remote_addr 10m;
 #下面是server虚拟主机的配置
 server
  {
    listen 80;#监听端口
    server_name localhost;#域名
    index index.html index.htm index.php;
    root /usr/local/webserver/nginx/html;#站点目录
      location ~ .*\.(php|php5)?$
    {
      #fastcgi_pass unix:/tmp/php-cgi.sock;
      fastcgi_pass 127.0.0.1:9000;
      fastcgi_index index.php;
      include fastcgi.conf;
    }
    location ~ .*\.(gif|jpg|jpeg|png|bmp|swf|ico)$
    {
      expires 30d;
  # access_log off;
    }
    location ~ .*\.(js|css)?$
    {
      expires 15d;
   # access_log off;
    }
    access_log off;
  }

}
```

检查配置文件nginx.conf的正确性命令：

```shell
[root@hadop conf]#  /usr/local/webserver/nginx/sbin/nginx -t
nginx: the configuration file /usr/local/webserver/nginx/conf/nginx.conf syntax is ok
nginx: configuration file /usr/local/webserver/nginx/conf/nginx.conf test is successful
```
### 启动 Nginx

Nginx 启动命令如下：

```shell
[root@hadop conf]#  /usr/local/webserver/nginx/sbin/nginx
[root@hadop conf]# ps -ef |grep nginx
root      31130      1  0 21:37 ?        00:00:00 nginx: master process /usr/local/webserver/nginx/sbin/nginx
www       31131  31130  0 21:37 ?        00:00:00 nginx: worker process
www       31133  31130  0 21:37 ?        00:00:00 nginx: worker process
root      32691  19903  0 22:41 pts/0    00:00:00 grep --color=auto nginx
```
### 访问站点
![image.png](https://img.hacpai.com/file/2019/09/image-d021529c.png)

在 windows 系统中访问 linux 中 中 nginx ，默认不能访问的，因为防火墙问题
（1 ）关闭防火墙
（2 ）开放访问的端口号，80 端口
查看开放的端口号

firewall-cmd --list-all
设置开放的端口号
firewall-cmd --add-service=http –permanent
firewall-cmd --add-port=80/tcp --permanent
重启防火墙
firewall-cmd –reload
![image.png](https://img.hacpai.com/file/2019/09/image-84d6b22e.png)

### Nginx 的常用的命令

进入 nginx 目录中
```shell
cd /usr/local/webserver/nginx/sbin/
```
1 、查看 nginx 版本号
```sehll
./nginx -v
```
2 、启动 nginx
```shell
./nginx
```
3 、停止 nginx
```shell
./nginx -s stop
```
4 、重新加载 nginx
```shell
./nginx -s reload
```

### Nginx 的配置文件
1 、nginx 配置文件位置

```shell
cd /usr/local/webserver/nginx/conf
```
![image.png](https://img.hacpai.com/file/2019/09/image-4995d120.png)

2 、配置文件中的内容
包含三部分内容
（1 ）全局块：配置服务器整体运行的配置指令
比如 worker_processes 1; 处理并发数的配置
（2 ）events 块 ：影响 Nginx 服务器与用户的网络连接
比如 worker_connections 1024; 支持的最大连接数为 1024
（3 ）http 块
还包含两部分：
http 全局块
server 块

安装时的配置文件：
```shell
#user  nobody;
#nginx进程，一般数值为cpu核数
worker_processes  1;
#错误日志存放目录
#error_log  logs/error.log;
#error_log  logs/error.log  notice;
#error_log  logs/error.log  info;
#进程pid存放位置
#pid        logs/nginx.pid;

#工作模式及连接数上限
events {
    #单个后台worker process进程的最大并发链接数
    worker_connections  1024;
}


http {
    #文件扩展名与类型映射表
    include       mime.types;
    #默认文件类型
    default_type  application/octet-stream;
    #设置日志模式
    #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
    #                  '$status $body_bytes_sent "$http_referer" '
    #                  '"$http_user_agent" "$http_x_forwarded_for"';
    #nginx访问日志
    #access_log  logs/access.log  main;
    #开启高效传输模式   
    sendfile        on;
    #激活tcp_nopush参数可以允许把httpresponse header和文件的开始放在一个文件里发布， 积极的作用是减少网络报文段的数量
    #tcp_nopush     on;
    #连接超时时间，单位是秒
    #keepalive_timeout  0;
    keepalive_timeout  65;
    #开启gzip压缩功能
    #gzip  on;
    
    #基于域名的虚拟主机
    server {
        #监听端口
        listen       80;
        server_name  localhost;
        #编码识别
        #charset koi8-r;
        #日志格式及日志存放路径
        #access_log  logs/host.access.log  main;

        location / {
            #站点根目录，即网站程序存放目录 
            root   html;
            #首页排序
            index  index.html index.htm;
        }
        #错误页面
        #error_page  404              /404.html;
        # 将服务器错误页面重定向到静态页面/50x.html
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }        

       
        #代理PHP脚本到Apache上监听127.0.0.1:80
        #location ~ \.php$ {
        #    proxy_pass   http://127.0.0.1;
        #}

   
        #将PHP脚本传递到正在监听127.0.0.1:9000的FastCGI服务器
        #location ~ \.php$ {
        #    root           html;
        #    fastcgi_pass   127.0.0.1:9000;
        #    fastcgi_index  index.php;
        #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
        #    include        fastcgi_params;
        #}

        #如果Apache的文档根目录与nginx的根目录一致，则拒绝访问.htaccess文件
        #location ~ /\.ht {
        #    deny  all;
        #}
    }



    #另一个虚拟主机，混合使用IP、名称和基于端口的配置
    #server {
    #    listen       8000;
    #    listen       somename:8080;
    #    server_name  somename  alias  another.alias;
    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}


    # HTTPS server
    #
    #server {
    #    listen       443 ssl;
    #    server_name  localhost;
    #    服务的证书
    #    ssl_certificate      cert.pem;
    #    服务端key
    #    ssl_certificate_key  cert.key;
    #    会话缓存
    #    ssl_session_cache    shared:SSL:1m;
    #    会话超时时间
    #    ssl_session_timeout  5m;
    #    #加密算法
    #    ssl_ciphers  HIGH:!aNULL:!MD5;
    #    启动加密算法
    #    ssl_prefer_server_ciphers  on;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}
}
```
使用中的配置文件
参考来源：[https://www.jianshu.com/p/e8c29a49801c]()
```shell
#user  nobody;
worker_processes  2;
error_log  logs/error.log;
pid  logs/nginx.pid;

#最大文件打开数（连接），可设置为系统优化后的ulimit -HSn的结果
worker_rlimit_nofile 360000;

events {
    #epoll是多路复用IO(I/O Multiplexing)中的一种方式,但是仅用于linux2.6以上内核,可以大大提高nginx的性能
    use epoll;
    #单个后台worker process进程的最大并发链接数
    worker_connections 100000;
    #是否串行处理连接
    multi_accept off;
}

http {
    #文件扩展名与类型映射表
    include    mime.types;
    #默认文件类型
    default_type  application/octet-stream;
    #设定请求缓存 
    #户端请求的最大可接受体大小，由行表示
    client_max_body_size 50m;
    #服务器名字的hash表大小
    server_names_hash_bucket_size 256;
    #客户机的请求头设置大小,对于绝大多数请求，1K的缓冲区大小就足够了
    client_header_buffer_size 256k;
    #用来指定客户端请求中较大的消息头的缓存最大数量和大小
    large_client_header_buffers 4 256k;
    
    #用于配置转发至tomcat后；tomcat获取客户端正式ip
    #允许重新定义和添加一些将被传输到代理服务器的请求头行。作为值，可以使用文本、变量及其组合。
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Real-Port $remote_port;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    
    #解决js跨域的问题
    #增加头标
    add_header Access-Control-Allow-Origin *;
    add_header Access-Control-Allow-Headers X-Requested-With;
    add_header Access-Control-Allow-Methods GET,POST,OPTIONS;
    
    #指定客户机请求体缓冲区大小。
    client_body_buffer_size 256k;
    #客户机的请求头设置读取超时。
    client_header_timeout 3m;
    #客户机的请求体设置读取超时。
    client_body_timeout 3m;
    #客户端分配响应超时时间。
    send_timeout 3m;
    #访问日志存放路径
    access_log   no;
    #客户端连接保持活动的超时时间，在超过这个时间之后服务器会关闭该链接。
    keepalive_timeout  0;
    #修改或隐藏Nginx的版本号
    server_tokens off;
    #虚拟主机配置
    server {
    #listen指令指定所包含的服务器接受的地址和端口。可以只指定地址、端口或服务器名作为地址      
    listen       80;
    #e用来指定ip地址或者域名，多个域名之间用空格分开
    server_name  localhost;
    #对 "/gzh" 启用反向代理
    location /gzh
    {
        #根据表达式来更改URI，或者修改字符串。注意重写表达式只对相对路径有效。
        #此处是将/gzh以前的地址替换成http://weixin.qq.com/q/xxx
        rewrite ^ http://weixin.qq.com/q/xxx;
    }
    
    location /test {
        default_type text/html;
        return 200 "207_80";
    }
    
    location / {
        default_type text/html;
        #根据规则的执行情况，返回一个状态值给客户端。
        return 200 "207_80";
    }
    location /status                                                                                       
    {                                                                                                
        #这个模块能够获取Nginx自上次启动以来的工作状态，此模块非核心模块，需要在编译的时候手动添加编译参数                                               
        stub_status on;        
        #日志                                                                            
        access_log /usr/local/nginx/logs/status.log;                                                                                     
    }      
    location /lua{
        default_type text/html;
        content_by_lua_file /usr/local/op/code/test.lua;
    }
    location /comm{
        default_type text/html;
        if ( $request_uri ~* /comm/gzhqr ) {
            content_by_lua_file /usr/local/op/code/redisget.lua;
        }
        proxy_pass http://192.168.1.209;
    }
    
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   html;
    }
}
    
server
{
    listen 192.168.88.100:8081;
    server_name www.cs.cc;
    default_type 'text/html';
    charset utf-8;
    # 日志级别
    error_log  logs/error.log info;    
    location /test {
        default_type text/html;
        return 200 "207_8081";
    }
    location /luac
    {
        default_type text/html;
        #lua_code_cache off;
        #$request_uri就是完整url中刨去最前面$host剩下的部分，比如http://www.baidu.com/pan/beta/test1?fid=3的就是/pan/beta/test1?fid=3
        #~* /devc/gzhqr表示含有/devc/gzhqr为true
        if ( $request_uri ~* /devc/test ) {
            content_by_lua_file /usr/local/op/lualib/tcode/test1.lua;
        }
    }
    location / {
        root   html;
        index  index8081.html index8081.htm;
    }
}


server {
    listen    8085;
    listen    443 ssl;
    #填写绑定证书的域名
    server_name www.cs.cc;
    #为服务器启用HTTPS。
    #ssl on;
    ssl_certificate /usr/local/op/nginx/conf/1_www.cs.cc_bundle.crt;
    ssl_certificate_key /usr/local/op/nginx/conf/2_www.cs.cc.key;
    ssl_session_timeout 5m;
    #指令启用所指示的协议。
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    #描述了允许的密码。密码以OpenSSL支持的格式分配
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    #要求协议SSLv3和TLSv1服务器密码优先于客户机的密码。
    ssl_prefer_server_ciphers on;
    charset utf-8;
    resolver 114.114.114.114;
    #日志级别
    error_log  logs/error.log info;    
    
    #网页
    location ~/social_security_homepage.html {
        rewrite ^(.*)$ /socialstop.html break;
    }
    #网络资源路径
    location /h5/huo/images/
    {
        proxy_pass  http://192.168.1.209:3000/images/;
    }
    #地址
    location /h5/
    {
        proxy_pass http://192.168.1.209:3000/;
    }
    
    #本地路径
    location /upload/file/
    {
        root /opt/nci/NCI_DOWN/;
    }
    if ($request_uri ~* /wxapp/sign/)
    {
        rewrite ^/(.*) http://weixin.qq.com/r/xxx? permanent;
    }
    
    #老管理平台图片的重写
    if ($request_uri ~* /download/downLoad.do\?loadFile=/ITCT_Mng/image)
    {   
        rewrite ^/(.*) https://www.cs.cc/upload/file$argloadFile? permanent;
    }
    
    
    
    #管理平台的资源转发
    if ($request_uri ~* ^(/PRO_GLPT/))
    {
        rewrite ^/PRO_GLPT/(.*)$ /glpt/$1 last;
        #没有匹配上返回403 状态码为444(此状态码是非标准的)，那么直接关闭此TCP连接
        #return code
        #return code text  因为要带响应内容，因此code不能是具有跳转功能的30x
        #return code URL    此时URI可以为URI做内部跳转，也可以是具有“http://”或者“https://”等协议的绝对URL，直接返回客户端，而code是30x(301, 302, 303, 307,308)
        #return URL 此时code默认为302，而URL必须是带“http://”等协议的绝对URL
        return 403;
    }
    
    location /glpt/
    {
        proxy_pass http://192.168.1.209:8088/PRO_GLPT/;
        proxy_redirect http:// https://;
        proxy_set_header  Host $host;
        proxy_set_header  X-Real-IP  $remote_addr;
        proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto  $scheme;
        proxy_next_upstream error timeout invalid_header;
    }
    if ($request_uri ~* ^(/REDIS/))
    {
        rewrite ^/REDIS/(.*)$ /redis/$1 last;
    }
    
    location /gitblit
    {
        proxy_pass http://192.168.1.209:10101/;
        proxy_redirect http:// https://;
        proxy_set_header  Host $host;
        proxy_set_header  X-Real-IP  $remote_addr;
        proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto  $scheme;
        proxy_next_upstream error timeout invalid_header;
    }
    
    
    location /luac
    {
        default_type text/html;
        #lua_code_cache off;
        if ( $request_uri ~* /devc/gzhqr ) {
            content_by_lua_file /usr/local/op/lualib/tcode/gzh_info.lua;
            #过期时间30天
            expires 30d;
        }
    }
    
    location /comm
    {
        default_type text/html;
        #设置变量
        set $lable 0;
        if ($request_uri ~* /main.*/homeinfo) {
            set $lable 1;
            content_by_lua_file /usr/local/op/lualib/tcode/busi/main/main.lua;
        }
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Real-Port $remote_port;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_pass http://192.168.1.207:8089/TKB_COMMON;
    }
    #维护中的页面
    location =/stoptaking.html
    { 
        #expires -1;
        add_header    Cache-Control no-store ;
        index stoptaking.html;
    }
}
```

