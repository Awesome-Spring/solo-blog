title: Spring相关知识点
date: '2019-09-08 22:47:52'
updated: '2019-09-14 21:49:35'
tags: [Spring]
permalink: /articles/2019/09/08/1567954072192.html
---
![](https://img.hacpai.com/bing/20180527.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

`本文转载至https://mp.weixin.qq.com/s/ry_IKRUwyL5jVDEqqRdWOw`
#### 1、谈谈你对  Spring  的理解
Spring 是一个开源框架，为简化企业级应用开发而生。Spring 可以是使简单的 JavaBean 实现以前只有 EJB 才能实现的功能。Spring 是一个 IOC 和 AOP 容器框架。
Spring 容器的主要核心是：
控制反转(IOC)，传统的 Java 开发模式中，当需要一个对象时，我们会自己使用 new 或者 getInstance 等直接或者间接调用构造方法创建一个对象。而在 Spring 开发模式中， Spring  容器使用了工厂模式为我们创建所需要的对象，不需要我们自己创建了，直接调用 Spring 提供的对象就可以了，这就是控制反转的思想。
依赖注入(DL)，Spring 使用 javaBean 对象的  set  方法或者带参数的构造方法为我们在创建所需对象时将其属性自动设置所需要的值的过程，就是依赖注入的思想。
面向切面编程(AOP)，在面向切面编程(oop) 思想中，我们将事物纵向抽成一个个的对象。而在面向切面编程中，我们将一个个的对象某些类似的方面横向抽成一个切面，对这个切面进行一些如权限控制、事务管理，记录日志等。公用操作处理的过程就是面向切面编程的思想。AOP 底层时动态代理，如果是接口采用 JDK 动态代理，如果是类采用CGLIB 方式实现动态代理。

#### 二、Spring 有哪些优点？
轻量级：Spring 在大小和透明性方面绝对属于轻量级的
控制反转(IOC)：Spring 使用控制反转技术实现了松耦合，依赖被注入到对象，而不是创建或寻找依赖对象。
面向切面编程(AOP)：Spring 支持面向切面编程，同时应用的业务逻辑与系统的服务分离开来。
容器：Spring 包含并管理应用程序对象的配置及生命周期
MVC 框架：Spring 的web框架是一个设计优良的web  MVC框架，很好的取代了一些web框架。
事务管理(Transaction)：Spring对下至本地业务上至全局业务(JAT)提供了统一的事务管理接口。

#### 三、Spring 中的设计模式
单例模式(singleton)：Spring 中的两种代理方式，若目标对象实现了若干接口，Spring 使用 jdk 的java.lang.reflect.Proxy类代理。若目标兑现没有实现任何接口，Spring 使用 CGLIB 库生成目标类的子类。在 Spring 的配置文件中设置 bean 默认为单例模式
模板方式模式：用来解决代码重复的问题
比如：RestTemplate、JmsTemplate、JdbcTemplate
前端控制器模式： Spring 提供了前端控制器 DispatherServlet  来 对请求进行分发。
依赖注入： 贯穿于 BeanFactory/ ApplicationContext 接口的核心理念
工厂模式： 在工厂模式中，我们在创建对象时不会对客户端暴露创建逻辑，并且是通过使用同一个接口来指向新创建的对象。Spring 中使用 beanFactory 来创建对象的实例。

#### 四、怎样开启注解装配以及常用注解
注解装配在默认情况下是不开启的，为了使用注解装配，我们必须在 Spring 配置文件中配置`<context:annotation-config/>`元素。
@Required注解  这个注解表明bean的属性必须在配置的时候设置，通过一个bean定义的显式的属性值或通过自动装配，若@Required注解的bean属性未被设置，容器将抛出BeanInitializationException。
@Autowired 注解提供了更细粒度的控制，包括在何处以及如何完成自动装配。它的用法和@Required一样，修饰setter方法、构造器、属性或者具有任意名称和/或多个参数的PN方法。
@Qualifier 注解当有多个相同类型的bean却只有一个需要自动装配时，将@Qualifier 注解和@Autowire 注解结合使用以消除这种混淆，指定需要装配的确切的bean。

#### 五、简单介绍下 Spring bean 的生命周期
bean 定义：再配置文件里面用<bean></bean> 来进行定义。
bean 初始化有两种方式：
1、再配置文件中通过指定 init-method 属性来完成，参数是要初始执行的函数名
2、实现 org.springframwork.beans.factory.InitializingBean 接口
bean 调用： 有三种方式可以得到 bean 实例，反射、静态工厂、实例工厂。并进行调用bean。
销毁：销毁有两种方式
1、使用配置文件中指定的 destory-method 属性
2、实现org.springframwork .bean.factory.DisposeableBean 接口 

#### 六、Spring  结构图
![image.png](https://img.hacpai.com/file/2019/09/image-ea751c87.png)



核心容器：包括  Beans 、 Core 、 Context、 EL 模块
Core 模块：封装了框架依赖的最底层部分，包括资源访问、类型转换以及一些常用的工具类。
Beans模块：提供了框架的基础部分，包括反转控制和依赖注入。其中 Bean  Factory 是容器核心，本质是“工厂设计模式” 的实现，而且无需编程实现 “ 单例设计模式” ，单例完全由容器控制，而且提倡面向接口编程，而非面向实现编程；所有应用程序对象及对象间关系由框架管理，从而真正把你从程序逻辑中维护对象之间的依赖关系提取出来，所有这些依赖关系都由 BeanFactory  来维护。
Context 模块： 以 Core 和 Beans  为基础，集成  Beans  模块功能并添加资源绑定、数据验证、Java EE 支持、容器生命周期、时间传播行为等；核心接口是 ApplicationContext。
EL 模块： 提供强大的表达式语言支持，支持访问和修改属性值，方法调用，支持访问及修改数组、容器和索引器，命名变量，支持算数和逻辑运算，支持从 Spring  容器获取 Bean，它也支持列表投影、选择和一般的列表聚合等。
(2) AOP、Aspects 模块：
AOP  模块： Spring AOP 模块提供了符合 AOP Alliance  规范的面向切面编程，提供比如日志记录、权限控制、性能统计等通用功能和业务逻辑分离的技术，并且能动态的把这些功能添加到需要的代码中；这样各专其职，降低业务逻辑和通用功能的耦合。
Aspects 模块： 提供了对AspectJ 的集成， AspectJ  提供了比 Spring AOP  更强大的功能。
数据访问/集成模块：该模块包括了  JDBC 、 ORM 、OXM 、JMS  和 事务管理
事务模块：该模块用于 Spring  管理事务，只要是 Spring 管理对象都能得到 Spring 管理事务的好处，无需在代码中进行事务控制了，而且支持编程和声明性的事务管理。
JDBC  模块： 提供了一个 JDBC 的样例模板，使用这些模板能消除传统沉长的 JDBC 编码还有必须的事务控制，而且能享受到 Spring 管理事物的好处。
ORM  模块： 提供与流行的“对象-关系“ 映射框架的无缝集成，包括hibernate、JPA、Mybatis等。而且可以使用 Spring 事务管理，无需额外控制事务。
OXM  模块：提供了一个对 Object/XML 映射实现，将 Java 对象映射成 XML 数据，或者将 XML 数据映射成  Java  对象， Object/XML  映射实现包括 JAXB、Castor、XMLBeans  和  XStream。
JMS  模块： 用于 JMS (Java Message Service)，提供一套 “消息生产者、消息消费者” 模板用于更加简单的使用  JMS，JMS  用于在两个应用程序之间，或分布式系统中发送消息，进行异步通信。
Web/Remoting  模块：Web/Remoting  模块包含了 Web、Web-Servlet、Web-Struts、Web-Prorlet。
Web模块： 提供了基础的web功能。例如文件上传、集成  IOC 容器、远程过程访问以及 Web  Service 支持。并提供一个  RestTemplate  类来提供方便的 Restful  service访问。
Web-Struts  模块： 提供了与  Struts  无缝集成。
Test  模块： Spring  支持  Junit 和  TestNG 测试框架，而且还额外提供了一些基于  Spring  的测试功能，比如在测试  Web框架时，模拟  Http  请求的功能。

#### 七、Spring能为我们做什么？

1、Spring  能帮我们根据配置文件创建及组装对象之间的依赖关系。Spring 根据配置文件来进行创建及组装对象间依赖关系，只需要改配置文件即可。
2、Spring  面向切面编程能帮助我们无耦合的实现日志记录，性能统计，安全控制。
Spring 面向切面编程能提供一种更好的方式来完成，一般通过配置方式，而且不需要在现有代码中添加任何额外代码，现有代码专注业务逻辑。
3、Spring  能非常简单的帮我们管理数据库事务。采用 Spring，我们只需获取连接，执行 SQL，其他事物相关的都交给 Spring 来管理了。 
4、Spring  还能与第三方数据库访问框架（如 Hibernate、JPA）无缝集成，而且自己也提供了一套 JDBC访问模板，来方便数据库访问。 
5、 Spring还能与第三方 Web（如 Struts）框架无缝集成，而且自己也提供了一套 Spring MVC框架，来方便 web 层搭建。 

#### 八、BeanFactory  常用的实现类有哪些?

Bean 工厂是工厂模式的一个实现，提供了控制反转功能，用来把应用的配置和依赖从正真的应用代码中分离。常用的 BeanFactory 实现有 DefaultListableBeanFactory 、 XmlBeanFactory、 ApplicationContext 等。XMLBeanFactory，最常用的就是org.springframework.beans.factory.xml.XmlBeanFactory ，它根据 XML 文件中的定义加载 beans。该容器从 XML 文件读取配置元数据并用它去创建一个完全配置的系统或应用。 

#### 九、解释 Spring  JDBC、Spring DAO  和  Spring  ORM

Spring-DAO 并非 Spring 的一个模块，它实际上是指示你写 DAO 操作、写好 DAO 操作的一些规范。因此，对于访问你的数据它既没有提供接口也没有提供实现更没有提供模板。在写一个 DAO 的时候，你应该使用 @Repository 对其进行注解，这样底层技术(JDBC，Hibernate，JPA，等等)的相关异常才能一致性地翻译为相应的 DataAccessException 子类。 
Spring-JDBC 提供了 Jdbc 模板类，它移除了连接代码以帮你专注于 SQL 查询和相关参数。Spring-JDBC 还提供了一个 JdbcDaoSupport，这样你可以对你的 DAO 进行扩展开发。它主要定义了两个属性：一个 DataSource 和一个 JdbcTemplate，它们都可以用来实现 DAO 方法。JdbcDaoSupport 还提供了一个将 SQL 异常转换为Spring DataAccessExceptions 的异常翻译器。 
对 于 每 一 种 技 术 ， 配 置 主 要 在 于 将 一 个DataSource bean 注 入 到 某 种 SessionFactory 或者 EntityManagerFactory 等 bean 中。纯 JDBC 不需要这样的一个集成类(JdbcTemplate 除外)，因为JDBC 仅依赖于一个 DataSource。如果你计划使用一种 ORM 技术，比如 JPA 或者 Hibernate，那么你就不需要 Spring-JDBC 模块了，你需要的是这个 Spring-ORM 模块。

#### 十、简单介绍一下  Spring  WEB  模块

Spring 的 WEB 模块是构建在 application context 模块基础之上，提供一个适合 web 应用的上下文。这个模块也包括支持多种面向 web 的任务，如透明地处理多个文件上传请求和程序级请求参数的绑定到你的业务对象。

#### 十一、Spring  配置文件有什么用？
Spring 配置文件是个 XML文件，这个文件包含了类信息，描述了如何配置它们，以及如何相互调用。

#### 十二、什么是  Spring  IOC 容器？
IOC 控制反转：Spring IOC 负责创建对象，管理对象。通过依赖注入（DI），装配对象，配置对象，并且管理这些对象的整个生命周期。

#### 十三、IOC 的优点是什么？

IOC 或 依赖注入把应用的代码量降到最低。它使应用容易测试，单元测试不再需要单例和 JNDI 查找机制。最小的代价和最小的侵入性使松散耦合得以实现。IOC 容器支持加载服务时的饿汉式初始化和懒加载。 

#### 十四、ApplicationContext  的实现类有哪些？
FileSystemXmlApplicationContext ：此容器从一个 XML 文件中加载 beans 的定义，XML Bean 配置文件的全路径名必须提供给它的构造函数。
ClassPathXmlApplicationContext：此容器也从一个 XML 文件中加载 beans 的定义，这里，你需要正确设置classpath 因为这个容器将在 classpath 里找 bean 配置。
WebXmlApplicationContext：此容器加载一个 XML 文件，此文件定义了一个 WEB 应用的所有 bean。 

#### 十五、BeanFactory 与 AppliacationContext 有什么区别？
1. BeanFactory
基础类型的 IOC 容器，提供完成的 IOC 服务支持。如果没有特殊指定，默认采用延迟初始化策略。相对来说，容器启动初期速度较快，所需资源有限。
2.ApplicationContext
ApplicationContext 是在 BeanFactory 的基础上构建，是相对比较高级的容器实现，除了 BeanFactory 的所有支持外，ApplicationContext 还提供了事件发布、国际化支持等功能。ApplicationContext 管理的对象，在容器启动后默认全部初始化并且绑定完成。 

#### 十七、 有哪些不同类型的 IOC（依赖注入）方式？
1.Set注入
2.构造器注入
3.静态工厂的方法注入
4.实例工厂的方法注入
#### 十八、什么是  Spring  Beans？
Spring  beans 是那些形成 Spring 应用的主干的 java 对象。它们被 Spring IOC 容器初始化，装配，和管理。这些 beans 通过容器中配置的元数据创建。比如，以 XML 文件中<bean/> 的形式定义。Spring 框架定义的 beans 都是单例 beans。

#### 十九、一个 Spring Beans 的定义需要包含什么？
一个 Spring Bean 的定义包含容器必知的所有配置元数据，包括如何创建一个 bean，它的生命周期详情及它的依赖。 

#### 二十、你怎样定义类的作用域?
当定义一个<bean> 在 Spring 里，我们还能给这个 bean 声明一个作用域。它可以通过 bean 定义中的 scope 属性来定义。如，当 Spring 要在需要的时候每次生产一个新的 bean 实例，bean 的 scope 属性被指定为prototype。另一方面，一个 bean 每次使用的时候必须返回同一个实例，这个 bean 的 scope 属性必须设为singleton。 

#### 二十一、Spring 支持的几种 bean 的作用域 ？
Spring 框架支持以下五种 bean 的作用域：
singleton: bean 在每个 Spring ioc 容器中只有一个实例。 prototype：一个 bean 的定义可以有多个实例。
request：每次 http 请求都会创建一个 bean，该作用域仅在基于 web 的 Spring ApplicationContext 情形下有效。
session：在一个 HTTP Session 中，一个 bean 定义对应一个实例。该作用域仅在基于 web 的Spring ApplicationContext 情形下有效。
global-session：在一个全局的 HTTPSession 中，一个 bean 定义对应一个实例。该作用域仅在基于 web 的Spring ApplicationContext 情形下有效。
缺省的 Spring bean 的作用域是 Singleton。 

#### 二十二、Spring 框架中的单例bean 是线程安全的吗? 
Spring 框架中的单例bean 不是线程安全的。

#### 二十三、什么是  Spring  的内部 Bean？
当一个 bean 仅被用作另一个bean 的属性时，它能被声明为一个内部 bean，为了定义inner bean，在Spring 的 基于 XML 的 配置元数据中，可以在 <property/>或 <constructor-arg/>元素内使用<bean/> 元素，内部 bean 通常是匿名的，它们的 Scope 一般是 prototype。 
```
<bean id="person2" class="com.zls.spring.dependency.injection.Person">
        <property name="name" value="zls"/>
        <property name="age" value="23"/>
        <property name="sex" value="女"/>
        <property name="car" >
            <bean class="com.zls.spring.dependency.injection.Car">
                <constructor-arg value="Ferrari" index="0"/>
                <constructor-arg value="Italy" index="1"/>
                <constructor-arg value="22500000" type="double"/>
            </bean>
        </property>
    </bean>
```


#### 二十四、在 Spring 中如何注入一个  Java 集合？
Spring 提供以下几种集合的配置元素：
<list>类型用于注入一列值，允许有相同的值。
<set> 类型用于注入一组值，不允许有相同的值。
<map> 类型用于注入一组键值对，键和值都可以为任意类型。
<props>类型用于注入一组键值对，键和值都只能为 String 类型。

#### 二十五、什么是 bean 的自动装配？
无须在 Spring 配置文件中描述 javaBean 之间的依赖关系（如配置<property>、<constructor-arg>）。IOC 容器会自动建立 javabean 之间的关联关系。

#### 二十六、解释不同方式的自动装配。
有五种自动装配的方式，可以用来指导 Spring 容器用自动装配方式来进行依赖注入。
1）no：默认的方式是不进行自动装配，通过显式设置 ref 属性来进行装配。
2）byName：通过参数名自动装配，Spring 容器在配置文件中发现 bean 的 autowire 属性被设置成 byname，之后容器试图匹配、装配和该 bean 的属性具有相同名字的 bean。
```
<beans>
  <bean id="HelloWorld" class="com.zls.demo.test.HelloWorld"
    autowire="byName">
        <property name="msg">
          <value>HelloWorld</value>
        </property>
  </bean>
  <bean id="date" class="java.util.Date"></bean>
</beans>
```

3）byType:：通过参数类型自动装配，Spring 容器在配置文件中发现 bean 的 autowire 属性被设置成 byType，
之后容器试图匹配、装配和该 bean 的属性具有相同类型的 bean。如果有多个 bean 符合条件，则抛出错误。
4）constructor：这个方式类似于 byType， 但是要提供给构造器参数，如果没有确定的带参数的构造器参数类型，将会抛出异常。
5）autodetect：首先尝试使用 constructor 来自动装配，如果无法工作，则使用 byType 方式。

#### 二十七、什么是基于Java的Spring 注解配置? 给一些注解的例子
基于 Java 的配置，允许你在少量的 Java 注解的帮助下，进行你的大部分 Spring 配置而非通过 XML 文件。
以@Configuration 注解为例，它用来标记类可以当做一个 bean 的定义，被 Spring IOC 容器使用。
另一个例子是@Bean 注解，它表示此方法将要返回一个对象，作为一个 bean 注册进 Spring 应用上下文。

#### 二十八、什么是基于注解的容器配置?
相对于 XML 文件，注解型的配置依赖于通过字节码元数据装配组件，而非尖括号的声明。开发者通过在相应的类，方法或属性上使用注解的方式，直接组件类中进行配置，而不是使用 xml 表述 bean 的装配关系。 

#### 二十九、怎样开启注解装配？
注 解 装 配 在 默 认 情 况 下 是 不 开 启 的 ， 为 了 使 用 注 解 装 配 ， 我 们 必 须在 Spring 配 置 文 件 中 配置 `<context:annotation-config/>`元素。 

#### 三十、在  Spring 框架中如何更有效地使用  JDBC ?
使用 SpringJDBC 框架，资源管理和错误处理的代价都会被减轻。所以开发者只需写 statements 和 query 从数据存取数据，JDBC 也可以在Spring 框架提供的模板类的帮助下更有效地被使用，这个模板叫 JdbcTemplate 。JdbcTemplate 类提供了很多便利的方法解决诸如把数据库数据转变成基本数据类型或对象，执行写好的或可调用的数据库操作语句，提供自定义的数据错误处理。 

#### 三十一、Spring 支持的  ORM  框架有哪些？
Spring 支持以下 ORM：
Hibernate、MyBatis、JPA (Java Persistence API)、TopLink、JDO (Java Data Objects)、OJB

#### 三十二、简单解释以下  Spring  的  AOP
AOP（Aspect Oriented Programming），即面向切面编程，可以说是OOP（Object Oriented Programming，面向对象编程）的补充和完善。OOP 引入封装、继承、多态等概念来建立一种对象层次结构，用于模拟公共行为的一个集合。不过 OOP 允许开发者定义纵向的关系，但并不适合定义横向的关系，例如日志功能。日志代码往往横向地散布在所有对象层次中，而与它对应的对象的核心功能毫无关系对于其他类型的代码，如安全性、异常处理和透明的持续性也都是如此，这种散布在各处的无关的代码被称为横切（cross cutting），在 OOP 设计中，它导致了大量代码的重复，而不利于各个模块的重用。
AOP 技术恰恰相反，它利用一种称为"横切"的技术，剖解开封装的对象内部，并将那些影响了多个类的公共行为封装到一个可重用模块，并将其命名为"Aspect"，即切面。所谓"切面"，简单说就是那些与业务无关，却为业务模块所共同调用的逻辑或责任封装起来，便于减少系统的重复代码，降低模块之间的耦合度，并有利于未来的可操作性和可维护性。
使用"横切"技术，AOP 把软件系统分为两个部分：核心关注点 和 横切关注点。业务处理的主要流程是核心关注点，与之关系不大的部分是横切关注点。横切关注点的一个特点是，他们经常发生在核心关注点的多处，而各处基本相似，比如权限认证、日志、事物。AOP 的作用在于分离系统中的各种关注点，将核心关注点和横切关注点分离开来。AOP 核心就是切面，它将多个类的通用行为封装成可重用的模块，该模块含有一组 API 提供横切功能。比如，一个日志模块可以被称作日志的 AOP 切面。根据需求的不同，一个应用程序可以有若干切面。在 Spring AOP 中，切面通过带有@Aspect 注解的类实现。 

#### 三十三、在 Spring AOP 中，关注点和横切关注的区别是什么？
关注点是应用中一个模块的行为，一个关注点可能会被定义成一个我们想实现的一个功能。横切关注点是一个关注点，此关注点是整个应用都会使用的功能，并影响整个应用，比如日志，安全和数据传输，几乎应用的每个模块都需要的功能。因此这些都属于横切关注点。 

#### 三十四、什么是连接点？
被拦截到的点，因为 Spring 只支持方法类型的连接点，所以在 Spring 中连接点指的就是被拦截到的方法，实际上连接点还可以是字段或者构造器。 

#### 三十五、 Spring  的通知是什么？有哪几种类型？

通知是个在方法执行前或执行后要做的动作，实际上是程序执行时要通过 Spring  AOP 框架触发的代码段。
Spring 切面可以应用五种类型的通知：
1）before：前置通知，在一个方法执行前被调用。
2）after:在方法执行之后调用的通知，无论方法执行是否成功。
3）after-returning:仅当方法成功完成后执行的通知。
4）after-throwing:在方法抛出异常退出时执行的通知。
5）around:在方法执行之前和之后调用的通知。 

#### 三十六、什么是切点？
切入点是一个或一组连接点，通知将在这些位置执行。可以通过表达式或匹配的方式指明切入点。 

#### 三十七、什么是目标对象？
被一个或者多个切面所通知的对象。它通常是一个代理对象。也指被通知（advised）对象。 

#### 三十八、什么是代理？
代理是通知目标对象后创建的对象。从客户端的角度看，代理对象和目标对象是一样的。 
#### 三十九、什么是织入？什么是织入应用的不同点？
织入是将切面和到其他应用类型或对象连接或创建一个被通知对象的过程。织入可以在编译时，加载时，或运行时完成。

#### 四十、事务面试

Spring支持两种类型的事务管理：
编程式事务管理：这意味你通过编程的方式管理事务，给你带来极大的灵活性，但是难维护。
声明式事务管理：这意味着你可以将业务代码和事务管理分离，你只需用注解和XML配置来管理事务。
声明式事务管理的定义：用在 Spring 配置文件中声明式的处理事务来代替代码式的处理事务。这样的好处是，事务管理不侵入开发的组件，具体来说，业务逻辑对象就不会意识到正在事务管理之中，事实上也应该如此，因为事务管理是属于系统层面的服务，而不是业务逻辑的一部分，如果想要改变事务管理策划的话，也只需要在定义文件中重新配置即可，这样维护起来极其方便。
代码如下所示：
```
<!-- 配置事务管理器=============================== -->
  <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
    <property name="dataSource" ref="dataSource"/>
  </bean>
  
  <!-- 配置事务的增强=============================== -->
  <tx:advice id="txAdvice" transaction-manager="transactionManager">
    <tx:attributes>
      <!-- 事务管理的规则 -->
      <!-- <tx:method name="save*" propagation="REQUIRED" isolation="DEFAULT"/>
      <tx:method name="update*" propagation="REQUIRED"/>
      <tx:method name="delete*" propagation="REQUIRED"/>
      <tx:method name="find*" read-only="true"/> -->
      <tx:method name="*" propagation="REQUIRED" read-only="false"/>
    </tx:attributes>
  </tx:advice>
  
  <!-- aop的配置 -->
  <aop:config>
    <aop:pointcut expression="execution(* com.itheima.tx.demo2.AccountServiceImpl.*(..))" id="pointcut1"/>
    <aop:advisor advice-ref="txAdvice" pointcut-ref="pointcut1"/>
  </aop:config>
```

