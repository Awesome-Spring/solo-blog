title: 我在 GitHub 上的开源项目
date: '2019-10-06 22:19:34'
updated: '2019-10-06 22:19:34'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [Crowdfunding-parent](https://github.com/Awesome-Spring/Crowdfunding-parent) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/Crowdfunding-parent/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/Crowdfunding-parent/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/Crowdfunding-parent/network/members "分叉数")</span>

基于SSM互联网金融类众筹项目



---

### 2. [solo-blog](https://github.com/Awesome-Spring/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.jiangtao.store`](http://www.jiangtao.store "项目主页")</span>

江涛的个人博客 - 艺术千秋,人生朝露



---

### 3. [miaosha](https://github.com/Awesome-Spring/miaosha) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/miaosha/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/miaosha/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/miaosha/network/members "分叉数")</span>

基于Spring Boot的秒杀Web项目



---

### 4. [SellOnline](https://github.com/Awesome-Spring/SellOnline) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/SellOnline/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/SellOnline/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/SellOnline/network/members "分叉数")</span>

A Spring Boot Project



---

### 5. [DataStructures](https://github.com/Awesome-Spring/DataStructures) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/DataStructures/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/DataStructures/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/DataStructures/network/members "分叉数")</span>

Data Structures Practice



---

### 6. [SSM_CRUD](https://github.com/Awesome-Spring/SSM_CRUD) <kbd title="主要编程语言">TSQL</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Awesome-Spring/SSM_CRUD/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/SSM_CRUD/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/SSM_CRUD/network/members "分叉数")</span>

A Simple SSM CRUD Demo



---

### 7. [o2o-shop](https://github.com/Awesome-Spring/o2o-shop) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Awesome-Spring/o2o-shop/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Awesome-Spring/o2o-shop/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Awesome-Spring/o2o-shop/network/members "分叉数")</span>

一个基于SSM框架的校园网上商城平台

